import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class FileHandling {

    private ArrayList<Person> personList;

    private void createList() {
        File file = new File("src/Persons.txt");
        personList = new ArrayList<>();
        // try-with-resources så scanner automatisk lukker efter brug
        try (Scanner reader = new Scanner(file)) {
            //laver et string-array fra hver linje i tekstfilen, som deles op ved komma
            while(reader.hasNext()) {
                String[] arr = reader.nextLine().split(",");
                String name = arr[0];
                String cpr = arr[1];
                personList.add(new Person(name, cpr));
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: " + e);
        }
    }

    public void getPersonList() {
        System.out.println("EMPLOYEES AND MEMBERS Name and cpr");
        System.out.printf("%-12s%4s\n","Name", "cpr");
        for (int i = 0; i < 40; i++) {
            System.out.print('*');
        }
        System.out.println();

        //kalder createList-metoden og går igennem listen
        createList();
        for (Person p : personList) {
            System.out.printf("%-12s%10s\n", p.getName(), p.getCpr());
        }

        for (int i = 0; i < 30; i++) {
            System.out.print('=');
        }
    }

}
