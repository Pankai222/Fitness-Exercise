// Af Mikael Steenberg Pasovski

public class Main {

    public static void main(String[] args) {
        Printer print = new Printer();
        print.printMembers();
        System.out.println();
        print.printEmployees();
        System.out.println();
        FileHandling fileH = new FileHandling();
        fileH.getPersonList();
    }
}
