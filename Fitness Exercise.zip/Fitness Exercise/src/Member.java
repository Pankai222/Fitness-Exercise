public class Member extends Person {

    private Boolean isBasic;

    public Member(Boolean isBasic, String name, String cpr) {
        super(name, cpr);
        this.isBasic = isBasic;
    }

    public String getMemberType() {
        if (isBasic) {
            return "Basic";
        } else {
            return "Full";
        }
    }

    public int monthlyFee() {
        int monthlyFee;
        getMemberType();
        if (isBasic) {
            monthlyFee = 199;
        } else {
            monthlyFee = 299;
        }
        return monthlyFee;
    }

}
