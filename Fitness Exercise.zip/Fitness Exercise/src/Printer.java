import java.util.ArrayList;

public class Printer {

    //printer members fra arraylist
    public void printMembers() {
        ArrayList<Member> memberList = new ArrayList<>();
        memberList.add(new Member(true, "Kalle", "0505661921"));
        memberList.add(new Member(true, "Jens", "1204980909"));
        memberList.add(new Member(false, "Katrine", "2301451920"));
        memberList.add(new Member(false, "Bob", "0312787623"));
        memberList.add(new Member(true, "Hansine", "1110951022"));

        System.out.println("FITNESS MEMBERS");
        //formaterer output vha printf, left-aligner al tekst
        System.out.printf("%-10s%-15s%-15s%-15s\n", "Name", "Cpr", "Member type", "Fee");
        for (int i = 0; i < 65; i++) {
            System.out.print('*');
        }
        //går igennem listen
        System.out.println();
        for (Member memb : memberList) {
            System.out.printf("%-10s%-15s%-15s%-15d\n", memb.getName(), memb.getCpr(),
                    memb.getMemberType(), memb.monthlyFee());
        }

        System.out.println();
        for (int i = 0; i < 50; i++) {
            System.out.print('=');
        }

    }

    public void printEmployees() {
        //arrayList af super class, tilføjer subclasses
        ArrayList<Employee> empList = new ArrayList<>();
        empList.add(new Instructor("Hansi","1204952311", 24));
        empList.add(new Administration("Bob", "0707672119", 37, 23000, 5));
        empList.add(new Instructor("Kaj", "1307856737", 31));
        empList.add(new Administration("Oline","2412051328",37,23000, 5));
        empList.add(new Instructor("Ida", "1607882356", 37));

        System.out.println("FITNESS EMPLOYEES");
        System.out.printf("%-10s%-15s%-15s%-15s%-15s\n", "Name", "Cpr", "Hours", "Salary", "Vacation");

        for (int i = 0; i < 65; i++) {
            System.out.print('*');
        }
        System.out.println();

            //tjekker efter subclass, og caster Employee hvis den er af Administration-typen, for at
            // få adgang til getVacation-metode
            for (Employee emp : empList) {
                if (emp instanceof Administration) {
                    System.out.printf("%-10s%-15s%-15d%-15d%-15d\n", emp.getName(),
                            emp.getCpr(),
                            emp.getHours(), emp.getSalary(), ((Administration) emp).getVacation());
                } else {
                    System.out.printf("%-10s%-15s%-15d%-15d\n", emp.getName(),
                            emp.getCpr(),
                            emp.getHours(), emp.getSalary());

                }
            }

        System.out.println();
        for (int i = 0; i < 50; i++) {
            System.out.print('=');
        }
    }

    public void printPersons() {

    }
}
